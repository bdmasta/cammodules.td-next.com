Thank you for downloading the "Embedded Vision STM32F7 Camera Development Kit" demo firmware and source code.
Follow the quick start guide and developers guide for usage and full details

This zip file contains
1) Demo firmware in case you need to reload the demo onto the board (xxx.bin file)
2) Source code for development purposes
